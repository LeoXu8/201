public class Node {
    String info;
    Node next;

    Node(String x) {
        info = x;
    }

    Node(String x, Node node) {
        info = x;
        next = node;
    }
}