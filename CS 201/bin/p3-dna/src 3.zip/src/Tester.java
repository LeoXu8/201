public class Tester{
    public static void main(String[] args) {
        CharDnaIterator test = new CharDnaIterator(new LinkStrand("ATCG"));
        while(test.hasNext()){
            System.out.println(test.next());
        }

        LinkStrand test2 = new LinkStrand("ATCG");
        test2.append("ATCG");
        test2.append("ATCG");
        System.out.println(test2.size());
        System.out.println(test2.toString());
    }
}