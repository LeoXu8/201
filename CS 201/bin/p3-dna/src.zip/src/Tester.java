public class Tester{
    public static void main(String[] args) {
        CharDnaIterator test = new CharDnaIterator(new LinkStrand("ATCG"));
        while(test.hasNext()){
            System.out.println(test.next());
        }
        
    }
}