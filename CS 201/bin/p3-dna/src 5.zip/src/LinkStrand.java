import java.util.ArrayList;

public class LinkStrand implements IDnaStrand {

    private Node myFirst, myLast;
    private long mySize;
    private int myAppends;
    private int myIndex;
    private Node myCurrent;
    private int myLocalIndex;

    public LinkStrand() {
        this("");
    }

    public LinkStrand(String s) {
        initialize(s);
    }

    private class Node {
        String info;
        Node next;

        Node(String x) {
            info = x;
        }

        Node(String x, Node node) {
            info = x;
            next = node;
        }
    }

    @Override
    public long size() {
        // TODO Auto-generated method stub
        return mySize;
    }

    @Override
    public void initialize(String source) {
        // TODO Auto-generated method stub
        Node initial = new Node(source, null);
        myFirst = initial;
        myLast = myFirst;
        mySize = source.length();
        myAppends = 0;
        myIndex = 0;
        myCurrent = myFirst;
        myLocalIndex = 0;
    }

    @Override
    public IDnaStrand getInstance(String source) {
        // TODO Auto-generated method stub
        return new LinkStrand(source);
    }

    @Override
    public IDnaStrand append(String dna) {
        // TODO Auto-generated method stub
        Node newNode = new Node(dna, null);
        myLast.next = newNode;
        myLast = newNode;
        mySize += dna.length();
        myAppends++;

        return this;
    }

    @Override
    public IDnaStrand reverse() {
        // TODO Auto-generated method stub
        Node temp = myFirst;
        while (temp != null) {
            StringBuilder string = new StringBuilder(temp.info);
            temp.info = string.reverse().toString();
            temp = temp.next;
        }
        Node rev = null;
        while (myCurrent != null) {
            Node temp2 = myCurrent.next;
            myCurrent.next = rev;
            rev = myCurrent;
            myCurrent = temp2;
        }
        LinkStrand reved = new LinkStrand();
        while (rev != null) {
            reved.append(rev.info);
            rev = rev.next;
        }
        return reved;
    }

    @Override
    public int getAppendCount() {
        // TODO Auto-generated method stub
        return myAppends;
    }

    @Override
    public char charAt(int index) {
        if (index > mySize || index < 0) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        if (index < myIndex) {
            myIndex = 0;
            myLocalIndex = 0;
            myCurrent = myFirst;
        }
        while (myIndex != index) {
            myIndex += 1;
            myLocalIndex += 1;
            if (myLocalIndex >= myCurrent.info.length()) {
                myLocalIndex = 0;
                myCurrent = myCurrent.next;
            }
        }
        return myCurrent.info.charAt(myLocalIndex);
    }

    @Override
    public String toString() {
        StringBuilder string = new StringBuilder();
        while (myFirst != null) {
            string.append(myFirst.info);
            myFirst = myFirst.next;
        }
        return string.toString();
    }

}
