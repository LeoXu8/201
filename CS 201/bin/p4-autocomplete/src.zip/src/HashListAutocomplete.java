import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashListAutocomplete implements Autocompletor {
    

    private static final int MAX_PREFIX = 10;
    private Map<String, List<Term>> myMap;
    private int mySize;

    public HashListAutocomplete(String[] terms, double[] weights) {
        if (terms == null || weights == null) {
            throw new NullPointerException("Invalid Conditions");
        }

        initialize(terms, weights);
    }

    @Override
    public List<Term> topMatches(String prefix, int k) {
        if (prefix == null)
            throw new NullPointerException("Prefix null");

        if (!myMap.containsKey(prefix))
            return new ArrayList<Term>();
        List<Term> all = myMap.get(prefix);
        return all.subList(0, Math.min(k, all.size()));
    }

    @Override
    public void initialize(String[] terms, double[] weights) {
        myMap = new HashMap<String, List<Term>>();
        String key;
        for (int i = 0; i < terms.length; i++) {
            Term term = new Term(terms[i], weights[i]);

            for (int j = 0; j < Math.min(terms[i].length(), MAX_PREFIX) + 1; j++) {
                key = (terms[i]).substring(0,j);
                myMap.putIfAbsent(key, new ArrayList<Term>());
                myMap.get(key).add(term);
            }
        }

        for (List<Term> value : myMap.values()) {
            Collections.sort(value,Comparator.comparing(Term::getWeight).reversed());
        }
    }

    @Override
    public int sizeInBytes() {
        if (mySize == 0) {
            for (Term t : myMap.get("")) {
                mySize += BYTES_PER_DOUBLE + BYTES_PER_CHAR * t.getWord().length();
            }
            for (String key : myMap.keySet()) {
                mySize += BYTES_PER_CHAR * key.length();
            }
        }
        return 0;
    }  
}

